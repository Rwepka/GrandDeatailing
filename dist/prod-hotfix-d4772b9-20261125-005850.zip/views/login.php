<?php
/**
 * Форма входа.
 *
 * @var array<int, string> $errors
 * @var array<string, mixed> $old
 */
$errors = $errors ?? [];
$old = $old ?? [];
?>
<section class="section">
    <div class="container">
        <h1>Вход</h1>
        <p class="lead">Войдите в личный кабинет, чтобы управлять записями.</p>
        <div class="card">

            <?php if (!empty($errors)): ?>
                <div class="form-errors" role="alert">
                    <strong>Пожалуйста, исправьте ошибки:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?= e($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?= e(url('/login')) ?>" novalidate>
                <?= csrf_field() ?>

                <div class="field-group">
                    <label for="login">Телефон или email</label>
                    <input type="text" name="login" id="login" placeholder="+7 900 000-00-00 или you@example.com" value="<?= e((string) ($old['login'] ?? '')) ?>" autocomplete="username"<?= field_aria($errors, 'login', 'err-login') ?>>
                    <?php if ($err = field_error($errors, 'login')): ?><p class="field-error" id="err-login"><?= e($err) ?></p><?php endif; ?>
                </div>

                <div class="field-group">
                    <label for="password">Пароль</label>
                    <input type="password" name="password" id="password" placeholder="Ваш пароль" autocomplete="current-password"<?= field_aria($errors, 'password', 'err-password') ?>>
                    <?php if ($err = field_error($errors, 'password')): ?><p class="field-error" id="err-password"><?= e($err) ?></p><?php endif; ?>
                </div>

                <div class="field-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember" value="1">
                        <span class="checkbox-ui" aria-hidden="true"></span>
                        Запомнить меня
                    </label>
                </div>

                <button type="submit" class="btn btn-accent">Войти</button>
            </form>

            <p>Нет аккаунта? <a class="auth-link" href="<?= e(url('/register')) ?>">Зарегистрироваться</a></p>
        </div>
    </div>
</section>
